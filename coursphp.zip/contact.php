<?php
    session_start();
    $title = "Contact";
    $nav = "contact";
    require_once 'header.php';
?>
<h1>Debug</h1>
<?php var_dump($_SESSION);?>
<h1>Nous contacter</h1>
<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Alias, aliquid? Sit inventore hic recusandae! Minima voluptatum commodi ut dicta nisi dolore consectetur id laboriosam? Voluptates laudantium cumque aspernatur et debitis.
<?php 
    require_once 'footer.php';
?>
