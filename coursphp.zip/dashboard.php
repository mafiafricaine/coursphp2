<?php
// session_start();

$title = "Dashboard";
$nav = "dashboard";
require_once 'header.php';
require_once 'functions/authentification.php';
// var_dump(is_connected());
if(!is_connected()):
    header("Location: login.php");
endif;
?>
    <h1>Bienvenu <?php echo $_SESSION['pseudo'] ;?> sur votre Dashboard</h1>



<?php
require_once 'footer.php';
?>